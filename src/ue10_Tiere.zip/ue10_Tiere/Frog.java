package ue10_Tiere;

public class Frog extends Animal
{

	public Frog(String color, int countEyes)
	{
		super(color, countEyes);
		// TODO Auto-generated constructor stub
	}

	public void walk()
	{
		System.out.println("Frosch h�pft.");
	}

	public void makeNoise()
	{
		System.out.println("Quaaaak!!");
	}

}
